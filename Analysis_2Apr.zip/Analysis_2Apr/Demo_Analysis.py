import os
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import pandas as pd
import google.generativeai as genai
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
try:
    load_dotenv()
    app = Flask(__name__)
    app.secret_key = os.urandom(24)  # Secret key for session
except Exception as e:
    logger.error(f"Error initializing application: {str(e)}")
    raise

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Define the folder for Excel files
EXCEL_FOLDER = 'excel_files/'

# Ensure Excel folder exists
try:
    os.makedirs(EXCEL_FOLDER, exist_ok=True)
except Exception as e:
    logger.error(f"Error creating Excel folder: {str(e)}")
    raise

# Initialize Gemini client
try:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY environment variable not set")
    genai.configure(api_key=api_key)
except Exception as e:
    logger.error(f"Error configuring Gemini API: {str(e)}")
    raise

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, email):
        self.id = id
        self.email = email

# Example user (only allows 'test@pabs.com' to log in)
users = {'test@pabs.com': {'password': None}}  # No password required

# Load user function for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User(user_id, user_id)

# Route for login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        
        # Check if the email is valid (only 'test@pabs.com' is allowed)
        if email == 'test@pabs.com':
            user = User(email, email)
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email address.', 'danger')
    
    return render_template('login.html')

# Route for logout
@app.route('/logout')
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Home page route (only accessible after login)
@app.route('/')
@login_required
def index():
    try:
        # List all Excel files in the folder
        excel_files = [f for f in os.listdir(EXCEL_FOLDER) if f.endswith(('.xls', '.xlsx'))]
        roles = ['Executive', 'Manager', 'Top Management']
        return render_template('index2.html', excel_files=excel_files, roles=roles)
    except FileNotFoundError:
        logger.error(f"Excel folder not found: {EXCEL_FOLDER}")
        return render_template('error.html', error="Excel folder not found"), 500
    except Exception as e:
        logger.error(f"Error loading index page: {str(e)}")
        return render_template('error.html', error="An unexpected error occurred"), 500

@app.route('/process', methods=['POST'])
def process_data():
    try:
        if 'file_name' not in request.form or 'role' not in request.form:
            return jsonify({'error': 'Missing required parameters'}), 400
            
        file_name = request.form['file_name']
        role = request.form['role']

        # Ensure the file exists
        file_path = os.path.join(EXCEL_FOLDER, file_name)
        if not os.path.exists(file_path):
            logger.warning(f"File not found: {file_path}")
            return jsonify({'error': 'File not found.'}), 404

        # Read the Excel file
        try:
            df = pd.read_excel(file_path)
        except pd.errors.EmptyDataError:
            logger.warning(f"Empty Excel file: {file_path}")
            return jsonify({'error': 'The selected file is empty.'}), 400
        except pd.errors.ParserError:
            logger.error(f"Error parsing Excel file: {file_path}")
            return jsonify({'error': 'Unable to parse the Excel file. The file may be corrupted.'}), 400

        # Check if DataFrame is empty
        if df.empty:
            return jsonify({'error': 'The selected file is empty.'}), 400

        # Send the DataFrame headers and content to Gemini for analysis
        response = analyze_with_gemini(df, role)
        return jsonify(response)

    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        return jsonify({'error': f'Error processing file: {str(e)}'}), 500

def analyze_with_gemini(df, role):
    try:
        headers = df.columns.tolist()
        data = df.to_dict(orient='records')
        logger.info("Preparing data for Gemini analysis")

        prompt = generate_prompt(headers, data, role)
        
        try:
            # Get the model
            model = genai.GenerativeModel("gemini-2.5-pro-exp-03-25")
            
            # Start streaming the content generation from Gemini
            analysis = ""
            for chunk in model.generate_content(
                prompt,
                stream=True,
            ):
                analysis += chunk.text
                print(chunk.text, end="")

            return parse_analysis(analysis)

        except Exception as e:
            logger.error(f"Gemini API error: {str(e)}")
            return {'error': f"Gemini API error: {str(e)}"}

    except Exception as e:
        logger.error(f"Error preparing data for analysis: {str(e)}")
        return {'error': f"Error preparing data for analysis: {str(e)}"}

def generate_prompt(headers, data, role):
    try:
        return f"""Role: {role}
Role: {role}

Analyze the following {data} and provide the data in the following categories in bullet points under section:

1. Positive & Negative Aspects with Numerical Data
    - Identify and list the positive and negative aspects of the data, focusing on the most significant numerical figures.

2. Anomalies
    - Highlight any anomalies, unusual trends, or outliers in the dataset.

3. Positive Trends
    - Identify any positive trends, such as improvements in sales, reductions in maintenance costs, etc.

4. Negative Trends
    - Highlight any negative trends, such as declining sales, increasing costs, etc.

5. Threats
    - Identify any potential threats to the business based on the data, such as sudden drops in performance.

6. Red Flags
    - Highlight any red flags that indicate serious issues or areas requiring attention.

7. Role Level Analysis
    - Provide an analysis tailored to the specific role of {role}. Summarize the company's performance based on the data, focusing on areas relevant to this role.
    """
    except Exception as e:
        logger.error(f"Error generating prompt: {str(e)}")
        raise

def parse_analysis(analysis):
    try:
        if not analysis:
            return {'error': 'No analysis was generated'}
        return {'analysis': analysis}  # Send raw Markdown-like text
    except Exception as e:
        logger.error(f"Error parsing analysis: {str(e)}")
        return {'error': f"Error parsing analysis: {str(e)}"}

if __name__ == '__main__':
    try:
        app.run(debug=True)
    except Exception as e:
        logger.critical(f"Failed to start application: {str(e)}")
 
import os
from flask import Flask, render_template, request, jsonify
import pandas as pd
from google import genai
from google.genai import types

from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()
app = Flask(__name__)

# Define the folder for Excel files
EXCEL_FOLDER = 'excel_files/'

# Ensure Excel folder exists
os.makedirs(EXCEL_FOLDER, exist_ok=True)

# # Initialize Gemini client
# client = genai.Client(
#     api_key=os.environ.get("GEMINI_API_KEY"),
# )
# Initialize Gemini client
print(os.getenv("GEMINI_API_KEY"))
client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY"),
)
@app.route('/')
def index():
    # List all Excel files in the folder
    excel_files = [f for f in os.listdir(EXCEL_FOLDER) if f.endswith(('.xls', '.xlsx'))]
    roles = ['Executive', 'Manager', 'Top Management']
    return render_template('index2.html', excel_files=excel_files, roles=roles)

@app.route('/process', methods=['POST'])
def process_data():
    file_name = request.form['file_name']
    role = request.form['role']

    # Ensure the file exists
    file_path = os.path.join(EXCEL_FOLDER, file_name)
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found.'})

    try:
        # Read the Excel file
        df = pd.read_excel(file_path)

        # Check if DataFrame is empty
        if df.empty:
            return jsonify({'error': 'The selected file is empty.'})

        # Send the DataFrame headers and content to Gemini for analysis
        response = analyze_with_gemini(df, role)
        return jsonify(response)

    except Exception as e:
        return jsonify({'error': f'Error processing file: {str(e)}'})

def analyze_with_gemini(df, role):
    headers = df.columns.tolist()
    data = df.to_dict(orient='records')
    print("Data sent to Gemini for analysis:", data)

    prompt = generate_prompt(headers, data, role)
    
    try:
        # Prepare content for the request
        contents = [
            types.Content(
                role="user",
                parts=[
                    types.Part.from_text(text=prompt),
                ],
            ),
        ]
        
        # Create the config for the content generation
        generate_content_config = types.GenerateContentConfig(
            response_mime_type="text/plain",
        )

        # Start streaming the content generation from Gemini
        analysis = ""
        for chunk in client.models.generate_content_stream(
            model="gemini-2.5-pro-exp-03-25",  # Ensure this is the correct model ID
            contents=contents,
            config=generate_content_config,
        ):
            analysis += chunk.text
            print(chunk.text, end="")

        return parse_analysis(analysis)

    except Exception as e:
        return {'error': f"Error analyzing data with Gemini: {str(e)}"}

def generate_prompt(headers, data, role):
    return f"""Role: {role}
Role: {role}

Analyze the following {data} and provide the following categories:

1. Positive & Negative Aspects with Numerical Data
    - Identify and list the positive and negative aspects of the data, focusing on the most significant numerical figures.

2. Anomalies
    - Highlight any anomalies, unusual trends, or outliers in the dataset.

3. Positive Trends
    - Identify any positive trends, such as improvements in sales, reductions in maintenance costs, etc.

4. Negative Trends
    - Highlight any negative trends, such as declining sales, increasing costs, etc.

5. Threats
    - Identify any potential threats to the business based on the data, such as sudden drops in performance.

6. Red Flags
    - Highlight any red flags that indicate serious issues or areas requiring attention.

7. Role Level Analysis
    - Provide an analysis tailored to the specific role of {role}. Summarize the company's performance based on the data, focusing on areas relevant to this role.
    """

def parse_analysis(analysis):
    return {
        'analysis': analysis  # Send raw Markdown-like text
    }

if __name__ == '__main__':
    app.run(debug=True)
